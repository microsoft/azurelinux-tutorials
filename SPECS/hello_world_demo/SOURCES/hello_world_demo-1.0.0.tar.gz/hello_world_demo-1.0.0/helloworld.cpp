#include <iostream>

int main() 
{
  std::cout << "Hello World Sample!\n";
  return 0;
}